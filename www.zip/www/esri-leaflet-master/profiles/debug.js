import config from './base.js';

config.output.file = 'dist/esri-leaflet-debug.js';

export default config;
