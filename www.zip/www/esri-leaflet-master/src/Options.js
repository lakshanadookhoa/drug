export var options = {
  attributionWidthOffset: 55
};

export default options;
